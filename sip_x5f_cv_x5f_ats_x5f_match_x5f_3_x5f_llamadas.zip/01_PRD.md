# 01 - PRD - CV ATS MATCH - 3 Llamadas

## Objetivo
Producto B2C: El usuario sube su CV y la oferta laboral (texto o pantallazo/imagen). El sistema contrarresta y genera CV 100% adaptado a esa oferta que pasa ATS.

## Por qué 3 llamadas (1 proveedor)
Llamada 1: Solo CV -> perfil_json (no se contamina con oferta)
Llamada 2: Solo OFERTA -> oferta_json (extrae keywords exactas que pide la empresa)
Llamada 3: Compara perfil vs oferta -> brecha_json + informe (match score, faltantes)

Calidad: Separar extracción evita alucinación. Si metes CV+oferta en 1 sola llamada, el LLM mezcla datos e inventa experiencia que el usuario no tiene.

## Flujo Usuario + Créditos
1. Front /cv-ats: Doble upload: [Sube tu CV] + [Sube oferta o pega texto / pantallazo]. Botón Analizar Match Gratis
2. Backend: Llamada 1 + 2 en paralelo, luego Llamada 3. Costo interno: 3 llamadas. Costo usuario: 1 crédito BONUS regalo (solo primera vez)
3. Front muestra INFORME BRECHA:
   - Match 48%
   - Keywords faltantes: SAP EWM, Licencia D...
   - Por qué te rechazaría el ATS
   - Perfil detectado
4. CTA: Generar CV Adaptado a esta oferta + Carta Presentación [3 créditos] -> Llamada 4? No, es Llamada 4 en realidad es Generación. Total producto = 4 llamadas LLM, 2 etapas de negocio.
   - Para simplificar: Etapa1 = 3 llamadas = Informe (1 crédito bonus). Etapa2 = 1 llamada = Generación (3 créditos)
5. Post-generación: Ofrecer Pack 5 CVs adaptados x 8 créditos, Mensaje LinkedIn x 1 crédito.

## Criterios Aceptación
- Si oferta es imagen (pantallazo Laborum/LinkedIn), OCR ya entrega texto plano y Llamada 2 debe extraer igual.
- Llamada 3 nunca puede inventar experiencia. Si falta herramienta, debe reportarla como faltante, no agregarla al CV.
- Informe debe citar textualmente requisitos de oferta.
