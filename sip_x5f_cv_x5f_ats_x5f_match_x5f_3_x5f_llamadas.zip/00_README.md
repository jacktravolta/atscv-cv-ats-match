# SIP - Producto CV ATS MATCH - 3 Llamadas - 1 Proveedor

Arquitectura: 1 proveedor LLM (el del router actual), 3 llamadas secuenciales para calidad.

Flujo: CV (pdf/doc/img) + OFERTA (texto/pdf/img pantallazo) -> 3 LLMs -> Informe Brecha (gratis) -> CV Adaptado (pago)

Ver 01_PRD.md
