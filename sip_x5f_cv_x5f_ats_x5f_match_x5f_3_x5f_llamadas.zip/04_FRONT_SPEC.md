# 04 - FRONT SPEC - Doble Upload

Ruta /cv-ats

Componentes:
- Header: "Sube tu CV y la oferta que quieres. Te digo si pasas el filtro ATS"
- Dos cards drag&drop:
  Card1: CV [PDF, DOCX, CSV, Imagen foto de CV impreso] -> usa parser existente -> cv_texto
  Card2: OFERTA [Pegar texto, o Subir PDF, o Subir pantallazo JPG/PNG] -> usa OCR existente -> oferta_texto
- Validación: Ambos requeridos para botón Analizar Match Gratis
- Loading: Muestra "Extrayendo tu perfil... Extrayendo oferta... Comparando..." (3 pasos para que vea valor)
- Resultado Informe: 
  - Gauge Match Score 0-100
  - Lista Keywords faltantes en rojo, presentes en verde
  - Texto informe_markdown
  - CTA grande: Generar CV Adaptado a esta oferta [3 créditos]
- Si sin créditos, mostrar paywall pack recomendado.

Post-generación:
- Preview CV ATS + Botón Descargar DOCX/PDF
- Nuevo Match Score 94%
- Upsell: Mensaje LinkedIn, 3 respuestas entrevista basadas en oferta, Pack 5 adaptaciones.

Analytics:
cv_ats_upload_cv, cv_ats_upload_oferta_tipo [texto|pdf|imagen], cv_ats_match_score, cv_ats_generado
