# 02 - API SPEC - 1 Proveedor, 3 Llamadas

Usar mismo router LLM y misma lógica créditos.

### Endpoint Orquestador (lo que llama el front)
POST /v1/cv-ats/match
Body: { "cv_texto": "... (ya pasado por parser/OCR)", "oferta_texto": "... (ya pasado por parser/OCR)", "user_id": "..." }
Lógica interna:
  Promise.all([
    LLM Call 1: system_cv_extract_perfil,
    LLM Call 2: system_cv_extract_oferta
  ])
  Luego LLM Call 3: system_cv_compara (input = perfil_json + oferta_json)

Response: { "perfil": {...}, "oferta": {...}, "brecha": {...}, "informe_texto": "markdown listo front", "creditos_restantes": 0 }

Costo usuario: 1 crédito (si es primera vez, 0 y se da bonus)

### Endpoint Generación
POST /v1/cv-ats/generar-adaptado
Body: { "perfil": {...}, "oferta": {...}, "brecha": {...}, "plantilla": "harvard|simple" }
Lógica: LLM Call 4: system_cv_genera_adaptado
Response: { "url_docx_cv": "s3...", "url_pdf_cv": "...", "url_carta": "...", "nuevo_match_score": 94 }

Costo usuario: 3 créditos

### Model
Usar mismo modelo del router (ej: gpt-4o-mini para extracción, gpt-4o para generación). 1 solo proveedor, no 3 proveedores diferentes.

### Tokens Estimados
Llamada 1: ~800 tokens
Llamada 2: ~600 tokens
Llamada 3: ~1000 tokens
Total informe: ~2400 tokens = ~$0.01 USD
